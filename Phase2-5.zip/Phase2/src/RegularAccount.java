/*
 * TEAM RED
 * -Mario Garcilazo
 * -Tyler Yocom
 * -Titus Duncan
 * -December Carroll
 *
 * RegularAccount class is a subclass of account class. 
 * It represents a regular bank account
 * 
 */


public class RegularAccount extends Account {
	
	// two constants representing interest rate and monthly fee
    private final double INTEREST_RATE = 0.06;
    private final double MONTHLY_FEE = 10.0;

    // constructor with account number, balance, and customer information
    public RegularAccount(int accountNumber, double balance, Customer customer) {
        super(accountNumber, balance, customer);
    }

    // method to apply interest
    public void applyInterest() {
        double interest = super.getBalance() * INTEREST_RATE;
        super.setBalance(super.getBalance() + interest);
    }

    // method to apply monthly fee
    public void applyMonthlyFee() {
        super.setBalance(super.getBalance() - MONTHLY_FEE);
    }

    // method to display account information
    public void display() {
        super.display();
        System.out.println("Account Type: Regular\n");
    }
}
