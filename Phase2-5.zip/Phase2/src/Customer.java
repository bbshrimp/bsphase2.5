/*
 * TEAM RED
 * -Mario Garcilazo
 * -Tyler Yocom
 * -Titus Duncan
 * -December Carroll
 *
 * Customer class represents the customer with a name. 
 * 
 */
import javafx.beans.property.SimpleStringProperty;



public class Customer {
	// private variable holds the name
    private String customerName;
    private String customerID;
    private static int currentCustomerID = 0;

 // constructor that takes a string parameter
    public Customer(String customerName) {
        this.customerName = customerName;
        this.customerID = createCustomerID ();
    }
    
    //currentCustomerID is a static variable that is incremented by 1 when the createCustomerID method is called
    private String createCustomerID () {
        currentCustomerID++;
        return String.format ("%05d", currentCustomerID);
    }

    // getter and setter methods for class attributes
    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
     
    public String getCustomerID() {
		return customerID;
	}

	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}

	// override method that returns a customer object. 
    @Override
    public String toString() {
    	return "ID: "+ customerID  + "    Name: " + customerName +"";
    }
}
