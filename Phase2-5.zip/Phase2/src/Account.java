/*
 * TEAM RED
 * -Mario Garcilazo
 * -Tyler Yocom
 * -Titus Duncan
 * -December Carroll
 * 
 * Account Class: represents a bank account. It has variables for the 
 * account number, balance, and customer.
 */
public class Account {
	// Instance variables
    private int accountNumber;
    private double balance;
    private Customer customer;
    
    // Account constructor
    public Account(int accountNumber, double balance, Customer customer) {
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.customer = customer;
    }
    
    // Getter for accountNumber
    public int getAccountNumber() {
        return accountNumber;
    }
    
    // Getter for balance
    public double getBalance() {
        return balance;
    }
    
    // Setter for balance
    public void setBalance(double balance) {
        this.balance = balance;
    }

    // Getter for customer
    public Customer getCustomer() {
        return customer;
    }

    // Method to deposit money to account
    public void deposit(double amount) {
        balance += amount;
    }

    // Method to withdraw money from account
    public void withdraw(double amount) {
        if (amount > balance) {
            System.out.println("Insufficient balance. Only " + balance + " available.");
            balance = 0;
        } else {
            balance -= amount;
        }
    }
    
    // Method to display account information
    public void display() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Balance: " + balance);
        System.out.println("Customer: " + customer.getCustomerName() + " (ID: " + customer.getCustomerID() + ")");
    }
    
 // Getter for customer ID
    public int getCustomerID() {
        return Integer.parseInt(customer.getCustomerID());
    }
}
