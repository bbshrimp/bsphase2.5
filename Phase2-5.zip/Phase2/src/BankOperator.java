/*
 * TEAM RED
 * -Mario Garcilazo
 * -Tyler Yocom
 * -Titus Duncan
 * -December Carroll
 * 
 * BankOperator provides a simple bank system. Provides an interface to the user
 * to create accounts, deposit, and withdraw money, display information and perform other 
 * operations. 
 */

import javafx.scene.control.TextArea;
import java.util.InputMismatchException;
import java.util.Optional;
import java.util.Scanner;
import javafx.scene.control.TextInputDialog;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class BankOperator extends Application {
	// class variables
    private static Scanner scanner;
    private static Bank bank = new Bank();
    private Stage window;
    public int accountNumber;
    public int initialBalance;

    // ties the style css sheet to the class
    public static final String Mainstyle = "style.css";
    
    // constructor for BankOperator class
    public BankOperator() {
    	// initiates a new bank
    	bank = new Bank();
    }
    
    // starting page of the application
    @Override
    public void start(Stage primaryStage) throws Exception {
        // Initialize the UI
        window = primaryStage;
        window.setTitle("Banking Application");
        
        // Create a logo label
        Label logo = new Label("");
        logo.getStyleClass().add("logo");

        // create welcome label
        Label welcomeLabel = new Label("Welcome!");
        welcomeLabel.getStyleClass().add("label-welcome");
        welcomeLabel.setAlignment(Pos.CENTER);
        
        //create a question label        
        Label questionLabel = new Label("Is this an existing account or would you like to createa new account?");
        questionLabel.getStyleClass().add("label-question");

        // create an existing button
        Button yesButton = new Button("Existing Account");
        yesButton.setOnAction(e -> {
            // Display buttons for account holders
            displayAccountHolderScreen();
        });

        // create a new account button
        Button noButton = new Button("New Account");
        noButton.setOnAction(e -> {
            // Display buttons for new customers
            displayNewCustomerScreen();
        });
        
        // create a new button to apply end of month updates
        Button applyEndOfMonthUpdatesButton = new Button("Apply End of Month Updates");
        applyEndOfMonthUpdatesButton.setOnAction(e -> {
            applyEndOfMonthUpdates();
            displayAccountHolderScreen();
            
        });
        
        // createa grid pane to layout UI elements
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);
        grid.add(logo, 0, 0);
        grid.add(welcomeLabel, 0,1, 2, 1);
        grid.add(questionLabel, 0, 2, 2, 1);
        
        // createa horizontal box to layout the buttons
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.getChildren().addAll(yesButton, noButton, applyEndOfMonthUpdatesButton);
        grid.add(buttonBox, 0, 3, 2, 1);     
        
        // create a scene and show it
        Scene scene = new Scene(grid, 600, 500);
        window.setScene(scene);
        scene.getStylesheets().add("style.css");
        window.show();
    }
    
    // creates a table view for the user
    @SuppressWarnings("unchecked")
	public TableView<Account> createTable() {
        // Create a new table.
        TableView<Account> table = new TableView<>();

        // Create the columns for the table.
        TableColumn<Account, Integer> accountNumberColumn = new TableColumn<>("Account Number");
        accountNumberColumn.setCellValueFactory(new PropertyValueFactory<>("accountNumber"));
        TableColumn<Account, String> accountTypeColumn = new TableColumn<>("Customer Info");
        accountTypeColumn.setCellValueFactory(new PropertyValueFactory<>("customer"));
        TableColumn<Account, Integer> balanceColumn = new TableColumn<>("Balance");
        balanceColumn.setCellValueFactory(new PropertyValueFactory<>("balance"));

        // Add the columns to the table.
        table.getColumns().setAll(accountNumberColumn, accountTypeColumn, balanceColumn);

        // Add the accounts to the table.
        for (Account account : bank.getAccounts()) {
            table.getItems().add(account);
        }
        
        return table;
    }
    
    // this is a new SCENE/VIEW for the user where allows the user to deposit, withdraw, or remove existing accounts
    private void displayAccountHolderScreen() {

        // Create UI elements
        Label accountNumberLabel = new Label("Account Number:");
        TextField accountNumberInput = new TextField();  
        Label amountLabel = new Label("Enter the amount:");
        TextField amountInput = new TextField();
        Button depositButton = new Button("Deposit");
        Button withdrawButton = new Button("Withdraw");
        Button backButton = new Button("Back");
        Button exitButton = new Button("Exit");
        
        // Set actions for deposit button
        depositButton.setOnAction(e -> {
        	try {
        		// try to parse account number and amount from the input fields
                accountNumber = Integer.parseInt(accountNumberInput.getText());
               double amount = Double.parseDouble(amountInput.getText());
               // if successful it calls the deposit() method
               depositMoney(accountNumber, amount);
           } catch (NumberFormatException ex) {
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setTitle("Invalid Input");
               alert.setContentText("Please enter valid account number and amount");
               alert.showAndWait();
           } catch (Exception ex) {
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setTitle("Error");
               alert.setContentText("An error occurred while depositing money");
               alert.showAndWait();
           }
        });

        // set actions for the withdraw button
        withdrawButton.setOnAction(e -> {
        	try {
                accountNumber = Integer.parseInt(accountNumberInput.getText());
               double amount = Double.parseDouble(amountInput.getText());
               // if successful calls the withdrawMoney() method
               withdrawMoney(accountNumber, amount);
           } catch (NumberFormatException ex) {
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setTitle("Invalid Input");
               alert.setContentText("Please enter valid account number and amount");
               alert.showAndWait();
           } catch (Exception ex) {
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setTitle("Error");
               alert.setContentText("An error occurred while depositing money");
               alert.showAndWait();
           }
        });

        //set actions for the backbutton
        backButton.setOnAction(e -> {
            try {
                start(window);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        
        // set actions for the exit button to close app
        exitButton.setOnAction(e -> {
            Platform.exit();
            System.exit(0);
        });
        
        // button actions for remove button
        Button removeButton = new Button("Remove Account");
        removeButton.setOnAction(e -> {
            // Get the account number from the accountNumberInput textField
            String accountNumber = accountNumberInput.getText();

            // Get the account object with the specified account number
            Account account = bank.getAccount(Integer.parseInt(accountNumberInput.getText()));
            
            // If the account object is not null, remove it from the accounts list
            if (account != null) {
            	bank.removeAccount(bank.getAccount(Integer.parseInt(accountNumberInput.getText())));
            	Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Account Removed");
                alert.setContentText("The account with the number " + accountNumber + " has been removed.");
                alert.showAndWait();
                displayAccountHolderScreen();
                
            }
        });
        
        

        // Set up layout for account holder screen
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);
        grid.add(accountNumberLabel, 0, 0);
        grid.add(accountNumberInput, 1, 0);
        grid.add(amountLabel, 0, 2);
        grid.add(amountInput, 1, 2);
        grid.add(backButton, 0, 4, 2, 1);
        
        // Set up HBox for deposit and withdraw buttons
        HBox buttonBox1 = new HBox(5, depositButton, withdrawButton);
        buttonBox1.setAlignment(Pos.CENTER);
        grid.add(buttonBox1, 0, 3, 2, 1);
        
        // Create a HBox to hold the back and exit buttons
        HBox buttonBox = new HBox(10, backButton, exitButton, removeButton);
        buttonBox.setAlignment(Pos.CENTER);
        grid.add(buttonBox, 0, 6, 2, 1);

        // Create a new table.
        TableView<Account> table = createTable();

    	VBox accountsLayout = new VBox(10);
        accountsLayout.setAlignment(Pos.CENTER);
        accountsLayout.setPadding(new Insets(10, 10, 10, 10));
        accountsLayout.getChildren().add(table);


        // Combine layouts for account holder screen and accounts table
        VBox layout = new VBox(10);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(10, 10, 10, 10));
        layout.getChildren().addAll(grid, accountsLayout);
        
        // Add accounts layout to the grid
        grid.add(accountsLayout, 0, 7, 2, 1);
        
        // Set the size of the columns
        for (TableColumn column : table.getColumns()) {
            column.prefWidthProperty().bind(table.widthProperty().divide(table.getColumns().size()));
            column.setMaxWidth(Double.MAX_VALUE);
        }

        
        // Display bank statistics
        double totalSum = 0.0;
        int zeroBalanceCount = 0;
        double maxBalance = Double.MIN_VALUE;
        Account maxBalanceAccount = null;
        
        for (Account account : bank.getAccounts()) {
            totalSum += account.getBalance();
            if (account.getBalance() == 0.0) {
                zeroBalanceCount++;
            }
            if (account.getBalance() > maxBalance) {
                maxBalance = account.getBalance();
                maxBalanceAccount = account;
            }
        }

        // Display the bank statistics
        Label bankStatisticsLabel = new Label("Bank Statistics:");
        TextArea totalSumTextArea = new TextArea();
        totalSumTextArea.setEditable(false);
        totalSumTextArea.setText("Total Sum: " + totalSum);

        // displayes the number of accounts with a balance of 0
        TextArea zeroBalanceCountTextArea = new TextArea();
        zeroBalanceCountTextArea.setEditable(false);
        zeroBalanceCountTextArea.setText("Number of Zero-Balance Accounts: " + zeroBalanceCount);

        // displays the average of ALL accounts
        TextArea averageBalanceTextArea = new TextArea();
        averageBalanceTextArea.setEditable(false);
        averageBalanceTextArea.setText("Average Balance: " + ( totalSum / bank.getAccounts().size()));
        
        // iterate through the accounts and find the account with the largest balance
        TextArea largestBalanceAccountTextArea = new TextArea();
        largestBalanceAccountTextArea.setEditable(false);
        if (maxBalanceAccount != null) {
            Account account = maxBalanceAccount;
            Integer accountNumber = account.getAccountNumber();
            largestBalanceAccountTextArea.setText("Account with Largest Balance: " + accountNumber);
        } else {
            largestBalanceAccountTextArea.setText("No account with a balance");
        }      
        
        // Add the bank statistics to the layout
        grid.add(bankStatisticsLabel, 0, 8);
        grid.add(totalSumTextArea, 0, 9, 2, 1);
        grid.add(zeroBalanceCountTextArea, 0, 10, 2, 1);
        grid.add(averageBalanceTextArea, 0, 11, 2, 1);
        grid.add(largestBalanceAccountTextArea, 0, 12, 2, 1);
        
        // Set up scene and show window
        Scene scene = new Scene(layout, 600, 600);
        window.setScene(scene);
        window.show();
    	       
    }

    // new SCENE/VIEW for user to create a new account in the bank
    private void displayNewCustomerScreen() {
    	
    	// Create UI components
        Button checkingButton = new Button("Create Checking Account");
        Button goldButton = new Button("Create Gold Account");
        Button regularButton = new Button("Create Regular Account");
        Button refreshButton = new Button("Refresh");
        Button backButton = new Button("Back");
        Button exitButton = new Button("Exit");
        
        // Set button styles
        checkingButton.setStyle("-fx-alignment: center;");
        goldButton.setStyle("-fx-alignment: center;");
        regularButton.setStyle("-fx-alignment: center;");
        
        // Create a VBox to hold the buttons
        VBox buttonsBox = new VBox(10, regularButton, checkingButton, goldButton);
        buttonsBox.setAlignment(Pos.CENTER);

        // Set button actions
        regularButton.setOnAction(e -> {
            // Create a new regular account
            createRegularAccount();
        });  
        checkingButton.setOnAction(e -> {
            // Create a new regular account
            createCheckingAccount();
        });
        goldButton.setOnAction(e -> {
            // Create a new regular account
            createGoldAccount();
        });

        refreshButton.setOnAction(e -> {
            
        });
        
        // button action for backbutton
        backButton.setOnAction(e -> {
			try {
				start(window);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});
        // action for the exit button
        exitButton.setOnAction(e -> {
            Platform.exit();
            System.exit(0);
        });

        // Set up layout for new customer screen
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);
        grid.add(buttonsBox, 0, 3, 2, 1);
        grid.add(refreshButton, 0, 4);
        grid.add(backButton, 1, 4);
        grid.add(exitButton, 1, 6);
                
        // Create a HBox to hold the back and exit buttons
        HBox buttonBox = new HBox(10, backButton, exitButton);
        buttonBox.setAlignment(Pos.CENTER);
        grid.add(buttonBox, 0, 6, 2, 1);
        
        // Create a new table.
        TableView<Account> table = createTable();

        
        VBox accountsLayout = new VBox(10);
        accountsLayout.setAlignment(Pos.CENTER);
        accountsLayout.setPadding(new Insets(10, 10, 10, 10));
        accountsLayout.getChildren().add(table);

        
        // Add accounts layout to the grid
        grid.add(accountsLayout, 0, 7, 2, 1);
        
        // Set the size of the columns
        for (TableColumn column : table.getColumns()) {
            column.prefWidthProperty().bind(table.widthProperty().divide(table.getColumns().size()));
            column.setMaxWidth(Double.MAX_VALUE);
        }
        
        // Display bank statistics
        double totalSum = 0.0;
        int zeroBalanceCount = 0;
        double maxBalance = Double.MIN_VALUE;
        Account maxBalanceAccount = null;
        
        for (Account account : bank.getAccounts()) {
        	double balance = account.getBalance();
            totalSum += balance;
            if (account.getBalance() == 0.0) {
                zeroBalanceCount++;
            }
            if (account.getBalance() > maxBalance) {
                maxBalance = balance;
                maxBalanceAccount = account;
            }
        }

        // Display the bank statistics
        Label bankStatisticsLabel = new Label("Bank Statistics:");
        TextArea totalSumTextArea = new TextArea();
        totalSumTextArea.setEditable(false);
        totalSumTextArea.setText("Total Sum: " + totalSum);

        TextArea zeroBalanceCountTextArea = new TextArea();
        zeroBalanceCountTextArea.setEditable(false);
        zeroBalanceCountTextArea.setText("Number of Zero-Balance Accounts: " + zeroBalanceCount);

        TextArea averageBalanceTextArea = new TextArea();
        averageBalanceTextArea.setEditable(false);
        averageBalanceTextArea.setText("Average Balance: " + ( totalSum / bank.getAccounts().size()));

        TextArea largestBalanceAccountTextArea = new TextArea();
        largestBalanceAccountTextArea.setEditable(false);
        if (maxBalanceAccount != null) {
            Account account = maxBalanceAccount;
            Integer accountNumber = account.getAccountNumber();
            largestBalanceAccountTextArea.setText("Account with Largest Balance: " + accountNumber);
        } else {
            largestBalanceAccountTextArea.setText("No account with a balance");
        }

        // Add the bank statistics to the layout
        grid.add(bankStatisticsLabel, 0, 8);
        grid.add(totalSumTextArea, 0, 9, 2, 1);
        grid.add(zeroBalanceCountTextArea, 0, 10, 2, 1);
        grid.add(averageBalanceTextArea, 0, 11, 2, 1);
        grid.add(largestBalanceAccountTextArea, 0, 12, 2, 1);
        
        // Display scene
        Scene scene = new Scene(grid, 600, 700);
        window.setScene(scene);
        window.show();
        
     
        
    }
    
    // Main Method
    public static void main(String[] args) {
    	// launches the application's starting scene
    	launch(args);   
    }
    
    // method creates a new checking account
	public void createCheckingAccount() {
		// Prompt the user to enter the customer ID and name
	    TextInputDialog dialog = new TextInputDialog();
	    dialog.setTitle("Regular Account Creation");
	    dialog.setHeaderText("Enter Customer Information");
	    dialog.setContentText("Enter Customer ID:");
	    
	    // check to ensure input is valid
	    Optional<String> customerID = dialog.showAndWait();
        if (customerID.isPresent()) {
        	String regex = "^[a-zA-Z0-9]+$";
        	if (!customerID.get().matches(regex)) {
        		Alert alert = new Alert(Alert.AlertType.ERROR);
        		alert.setTitle("Invalid Input");
        		alert.setHeaderText("Customer ID must contain only letters and numbers");
        		alert.showAndWait();
        		return;
        	}
        } else {
        	return;
        }
        
        // Check if the customer ID already exists in an existing account
        boolean customerIdExistsInExistingAccount = false;
        if (customerID.isPresent()) {
        	int customerId = Integer.parseInt(customerID.get());
        	customerIdExistsInExistingAccount = bank.getAccounts().stream().anyMatch(account -> account.getCustomerID() == customerId);
        }

        // check accounts to ensure the input does not ALREADY EXISTS
        if (customerIdExistsInExistingAccount) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Customer ID already exists");
            alert.setContentText("Please enter a different customer ID.");
            alert.showAndWait();
            return;
        }
        
        // enter name and check for validity
        dialog.getEditor().clear();
        dialog.setContentText("Enter Customer Name:");
        Optional<String> customerNameInput = dialog.showAndWait();
        String customerName = customerNameInput.get().trim();
        if (!customerName.matches("[a-zA-Z ]+")) {
        	Alert alert = new Alert(AlertType.ERROR);
	        alert.setTitle("Input Error");
	        alert.setHeaderText("Invalid customer name");
	        alert.setContentText("Please enter a valid customer name containing only letters.");
	
	        alert.showAndWait();
	       return;
        }
       
        // clear the input
        dialog.getEditor().clear();
        
	    // Prompt the user to enter the account number and initial balance
	    dialog = new TextInputDialog();
	    dialog.setTitle("Regular Account Creation");
	    dialog.setHeaderText("Enter Account Information");
	    dialog.setContentText("Enter Account Number:");
	    
	    //check for valid input 
	    Optional<String> accountNumberInput = dialog.showAndWait();
	    try {
            accountNumber = Integer.parseInt(accountNumberInput.get());
	    	} catch (NumberFormatException e) {
	    		Alert alert = new Alert(AlertType.ERROR);
	    		alert.setTitle("Error");
	    		alert.setHeaderText("Invalid input");
	    		alert.setContentText("Please enter a valid account number (numbers only)");
	    		alert.showAndWait();
	        	return;
	    	}
	    // Check if the account already exists
	    boolean accountExists = bank.getAccounts().stream().anyMatch(account -> account.getAccountNumber() == accountNumber);

	    // check to see if account exists
	    if (accountExists) {
	        Alert alert = new Alert(Alert.AlertType.ERROR);
	        alert.setTitle("Error");
	        alert.setHeaderText("Account already exists");
	        alert.setContentText("Please enter a different account number.");
	        alert.showAndWait();
	        return;
	    }
	    
	    // check for validity of input
	    dialog.getEditor().clear();
	    dialog.setContentText("Enter Initial Balance:");
	    Optional<String> initialBalanceInput = dialog.showAndWait();
	    try {
            initialBalance = Integer.parseInt(initialBalanceInput.get());
	    	} catch (NumberFormatException e) {
	    		Alert alert = new Alert(AlertType.ERROR);
	    		alert.setTitle("Error");
	    		alert.setHeaderText("Invalid input");
	    		alert.setContentText("Please enter a valid initial balance (numbers only)");
	    		alert.showAndWait();
	    		return;
	    	}

	    // Create the customer
	    Customer customer = new Customer(customerNameInput.get());

	    // Create the regular account
	    CheckingAccount account = new CheckingAccount(Integer.parseInt(accountNumberInput.get()), Double.parseDouble(initialBalanceInput.get()), customer);

	    // Add the account to the list of accounts
	    bank.addAccount(account);

	    System.out.println("Regular Account created successfully!");

	    // Get all accounts
	    ObservableList<Account> accounts = FXCollections.observableArrayList(bank.getAccounts());
	    
	    System.out.println(accounts);

	    // Add accounts to table
	    createTable().setItems(accounts);
	    
	    displayNewCustomerScreen();
		
	}

	// method creates a new gold account
	public void createGoldAccount() {
		// Prompt the user to enter the customer ID and name
	    TextInputDialog dialog = new TextInputDialog();
	    dialog.setTitle("Gold Account Creation");
	    dialog.setHeaderText("Enter Customer Information");
	    dialog.setContentText("Enter Customer ID:");  
	    
	    // check for input validity
	    Optional<String> customerID = dialog.showAndWait();
            if (customerID.isPresent()) {
            	String regex = "^[a-zA-Z0-9]+$";
            	if (!customerID.get().matches(regex)) {
            		Alert alert = new Alert(Alert.AlertType.ERROR);
            		alert.setTitle("Invalid Input");
            		alert.setHeaderText("Customer ID must contain only letters and numbers");
            		alert.showAndWait();
            		return;
            	}
            } else {
            	return;
            }
            
            // Check if the customer ID already exists in an existing account
            boolean customerIdExistsInExistingAccount = false;
            if (customerID.isPresent()) {
            	int customerId = Integer.parseInt(customerID.get());
            	customerIdExistsInExistingAccount = bank.getAccounts().stream().anyMatch(account -> account.getCustomerID() == customerId);
            }
            
            // check to see if customerID exists
            if (customerIdExistsInExistingAccount) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Customer ID already exists");
                alert.setContentText("Please enter a different customer ID.");
                alert.showAndWait();
                return;
            }
            
        dialog.getEditor().clear();
        
        // ask for input and check for validity 
	    dialog.setContentText("Enter Customer Name:");
	    Optional<String> customerNameInput = dialog.showAndWait();
            String customerName = customerNameInput.get().trim();
            if (!customerName.matches("[a-zA-Z ]+")) {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Input Error");
                alert.setHeaderText("Invalid customer name");
                alert.setContentText("Please enter a valid customer name containing only letters.");

                alert.showAndWait();
                return;
            }
            
        //clear input for next dialog box
        dialog.getEditor().clear();
	    // Prompt the user to enter the account number and initial balance
	    dialog = new TextInputDialog();
	    dialog.setTitle("Gold Account Creation");
	    dialog.setHeaderText("Enter Account Information");
	    dialog.setContentText("Enter Account Number:");
	    Optional<String> accountNumberInput = dialog.showAndWait();
            try {
            	accountNumber = Integer.parseInt(accountNumberInput.get());
            } 
            catch (NumberFormatException e) {
             Alert alert = new Alert(AlertType.ERROR);
             alert.setTitle("Error");
             alert.setHeaderText("Invalid input");
             alert.setContentText("Please enter a valid account number (numbers only)");
             alert.showAndWait();
             return;
            }
            // Check if the account already exists
    	    boolean accountExists = bank.getAccounts().stream().anyMatch(account -> account.getAccountNumber() == accountNumber);

    	    if (accountExists) {
    	        Alert alert = new Alert(Alert.AlertType.ERROR);
    	        alert.setTitle("Error");
    	        alert.setHeaderText("Account already exists");
    	        alert.setContentText("Please enter a different account number.");
    	        alert.showAndWait();
    	        return;
    	    }
            
        dialog.getEditor().clear();
        
        // ask for initial balance and validate it
	    dialog.setContentText("Enter Initial Balance:");
	    Optional<String> initialBalanceInput = dialog.showAndWait();
            try {
                 initialBalance = Integer.parseInt(initialBalanceInput.get());
            } 
            catch (NumberFormatException e) {
            	Alert alert = new Alert(AlertType.ERROR);
            	alert.setTitle("Error");
            	alert.setHeaderText("Invalid input");
            	alert.setContentText("Please enter a valid initial balance (numbers only)");
            	alert.showAndWait();
            	return;
            }

	    // Create the customer
	    Customer customer = new Customer(customerNameInput.get());

	    // Create the regular account
	    GoldAccount account = new GoldAccount(Integer.parseInt(accountNumberInput.get()), Double.parseDouble(initialBalanceInput.get()), customer);

	    // Add the account to the list of accounts
	    bank.addAccount(account);

	    System.out.println("Gold Account created successfully!");

	    // Get all accounts
	    ObservableList<Account> accounts = FXCollections.observableArrayList(bank.getAccounts());
	    
	    System.out.println(accounts);

	    // Add accounts to table
	    createTable().setItems(accounts);
	    
	    displayNewCustomerScreen();
	 }

	// creates a new regular account
	// Create a new regular account for a customer
	private void createRegularAccount() {
		// Prompt the user to enter the customer ID and name
	    TextInputDialog dialog = new TextInputDialog();
	    dialog.setTitle("Regular Account Creation");
	    dialog.setHeaderText("Enter Customer Information");
	    dialog.setContentText("Enter Customer ID:");
	    Optional<String> customerID = dialog.showAndWait();
            if (customerID.isPresent()) {
            	String regex = "^[a-zA-Z0-9]+$";
            	if (!customerID.get().matches(regex)) {
            		Alert alert = new Alert(Alert.AlertType.ERROR);
            		alert.setTitle("Invalid Input");
            		alert.setHeaderText("Customer ID must contain only letters and numbers");
            		alert.showAndWait();
            		return;
            	}
            } else {
            	return;
            }
            // Check if the customer ID already exists in an existing account
            boolean customerIdExistsInExistingAccount = false;
            if (customerID.isPresent()) {
            	int customerId = Integer.parseInt(customerID.get());
            	customerIdExistsInExistingAccount = bank.getAccounts().stream().anyMatch(account -> account.getCustomerID() == customerId);
            }

            // validate customerID
            if (customerIdExistsInExistingAccount) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Customer ID already exists");
                alert.setContentText("Please enter a different customer ID.");
                alert.showAndWait();
                return;
            }
            
        dialog.getEditor().clear();
	    dialog.setContentText("Enter Customer Name:");
	    Optional<String> customerNameInput = dialog.showAndWait();
            String customerName = customerNameInput.get().trim();
            if (!customerName.matches("[a-zA-Z ]+")) {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Input Error");
                alert.setHeaderText("Invalid customer name");
                alert.setContentText("Please enter a valid customer name containing only letters.");

                alert.showAndWait();
                return;
            }

        dialog.getEditor().clear();
	    // Prompt the user to enter the account number and initial balance
	    dialog = new TextInputDialog();
	    dialog.setTitle("Regular Account Creation");
	    dialog.setHeaderText("Enter Account Information");
	    dialog.setContentText("Enter Account Number:");
	    Optional<String> accountNumberInput = dialog.showAndWait();
            try {
                 accountNumber = Integer.parseInt(accountNumberInput.get());
            } catch (NumberFormatException e) {
             Alert alert = new Alert(AlertType.ERROR);
             alert.setTitle("Error");
             alert.setHeaderText("Invalid input");
             alert.setContentText("Please enter a valid account number (numbers only)");
             alert.showAndWait();
             return;
            }
            
            // Check if the account already exists
    	    boolean accountExists = bank.getAccounts().stream().anyMatch(account -> account.getAccountNumber() == accountNumber);

    	    if (accountExists) {
    	        Alert alert = new Alert(Alert.AlertType.ERROR);
    	        alert.setTitle("Error");
    	        alert.setHeaderText("Account already exists");
    	        alert.setContentText("Please enter a different account number.");
    	        alert.showAndWait();
    	        return;
    	    }
            
        dialog.getEditor().clear();
	    dialog.setContentText("Enter Initial Balance:");
	    Optional<String> initialBalanceInput = dialog.showAndWait();
            try {
                 initialBalance = Integer.parseInt(initialBalanceInput.get());
            } catch (NumberFormatException e) {
             Alert alert = new Alert(AlertType.ERROR);
             alert.setTitle("Error");
             alert.setHeaderText("Invalid input");
             alert.setContentText("Please enter a valid initial balance (numbers only)");
             alert.showAndWait();
        return;
            }

	    // Create the customer
	    Customer customer = new Customer(customerNameInput.get());

	    // Create the regular account
	    RegularAccount account = new RegularAccount(Integer.parseInt(accountNumberInput.get()), Double.parseDouble(initialBalanceInput.get()), customer);

	    // Add the account to the list of accounts
	    bank.addAccount(account);

	    System.out.println("Regular Account created successfully!");

	    // Get all accounts
	    ObservableList<Account> accounts = FXCollections.observableArrayList(bank.getAccounts());
	    
	    System.out.println(accounts);

	    // Add accounts to table
	    createTable().setItems(accounts);
	    
	    displayNewCustomerScreen();
	}
	
	// deposits money into the appropriate account

	public void depositMoney(int accountNumber, double amount) {
		// Check if the account exists
	    Account account = bank.getAccount(accountNumber);
	    if (account == null) {
	        System.out.println("Invalid account number");
	        return;
	    }

	    // Deposit the money
	    bank.deposit(account, amount);
	    System.out.println(amount + " deposited successfully to account number " + accountNumber);
	    account.display();
	    
	    //refresh the pages
	    displayAccountHolderScreen();	    
	}
	
	// withdraws money from the appropriate account
    
    // method prompts the user to enter an account number and the amount to withdraw.
    public void withdrawMoney(int accountNumber, double amount) {
    	// Check if the account exists
	    Account account = bank.getAccount(accountNumber);
	    if (account == null) {
	        Alert alert = new Alert(AlertType.ERROR);
	        alert.setTitle("Error");
	        alert.setHeaderText("Invalid account number");
	        alert.setContentText("Please enter a valid account number.");
	        alert.showAndWait();
	        return;
	    }
	    
	    // Check if the withdrawal will put the account balance in the negative
	    if (account.getBalance() - amount < 0) {
	        Alert alert = new Alert(AlertType.CONFIRMATION);
	        alert.setTitle("Confirmation");
	        alert.setHeaderText("Withdrawal will put the account balance in the negative.");
	        alert.setContentText("Are you sure you want to proceed?");
	        Optional<ButtonType> result = alert.showAndWait();
	        if (result.get() != ButtonType.OK) {
	            return;
	        }
	    }

	    // Withdraw the money
	    account.withdraw(amount);
	    account.setBalance(account.getBalance() - amount);
	    System.out.println(amount + " withdrawn successfully from account number " + accountNumber);
	    account.display();

	    displayAccountHolderScreen();
    }

    // applies end of month updates

    // applies fees and interest rate when it is invoked
    public static void applyEndOfMonthUpdates() {
     bank.applyInterest();
     bank.applyMonthlyFee();
     System.out.println("End of month updates applied successfully!");
     }
    
    // method to remove account from bank
     
    // method prompts the user to enter an account number and removes the account from the bank. 
    public static void removeAccount(int accountNumber) {
	    while (true) {
	        try {
	            accountNumber = scanner.nextInt();
	        } catch (InputMismatchException e) {
	            System.out.println("Invalid input. Please enter an integer for the account number.");
	            scanner.nextLine(); // consume the entire line, including invalid input
	            continue; // restart the loop
	        }
	        
	        Account account = bank.getAccount(accountNumber);
	        if (account == null) {
	            System.out.println("Invalid account number.");
	            break; // restart the loop
	        }
	        
	        bank.removeAccount(account);
	        System.out.println("Account removed successfully!");
	        break; // exit the loop since the withdrawl was successful
    	}
    }
    
    // displays account information to the user
          
    // method prompts the user to enter an account number and displays the details
    public static void displayAccountInformation() {
        System.out.println("...Displaying an Account...");
        while (true) {
	        System.out.print("Enter the account number: ");
	        int accountNumber;
	        try {
	            accountNumber = scanner.nextInt();
	        } catch (InputMismatchException e) {
	            System.out.println("Invalid input. Please enter an integer for the account number.");
	            scanner.nextLine(); // consume the entire line, including invalid input
	            continue; // restart the loop
	        }
	        Account account = bank.getAccount(accountNumber);
	        if (account == null) {
	            System.out.println("Invalid account number.");
	            continue; // restart the loop
	        }
	        
	        account.display();
	        System.out.println("Account displayed successfully!");
	        break; // exit the loop since the withdrawl was successful
	    	}
    }	

    // displays bank stats to the user
    // method displays the bank's overall statistics
	public static void displayBankStatistics() {
        bank.displayBankStatistics();
    
    }
}
