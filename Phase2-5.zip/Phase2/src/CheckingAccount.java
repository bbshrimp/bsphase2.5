/*
 * TEAM RED
 * -Mario Garcilazo
 * -Tyler Yocom
 * -Titus Duncan
 * -December Carroll
 * 
 * Checking Account: The checking account class is a subclass of the Account class
 * t extends the Account class and adds additional functionality specific 
 * to checking accounts, such as tracking transaction counts and applying transaction fees.
 */


// extends the account class
public class CheckingAccount extends Account {
	// private variables 
    private int transactionCount;
    private static final int TRANSACTION_LIMIT = 2;
    private static final double TRANSACTION_FEE = 3.0;

    // constructor that takes three arguments and calls the superclass 
    public CheckingAccount(int accountNumber, double balance, Customer customer) {
        super(accountNumber, balance, customer);
        this.transactionCount = 0;
    }

    // overrides the deposit method from the superclass
    @Override
    public void deposit(double amount) {
    	// calls the superclass deposit method with the amount argument
        super.deposit(amount);
        transactionCount++;
        if (transactionCount > TRANSACTION_LIMIT) {
            deductTransactionFee();
        }
    }

    // overrides the withdraw method from the superclass
    @Override
    public void withdraw(double amount) {
        super.withdraw(amount);
        transactionCount++;
        if (transactionCount > TRANSACTION_LIMIT) {
            deductTransactionFee();
        }
    }

    // method that deducts the transaction fee from the balance.
    private void deductTransactionFee() {
        super.setBalance(super.getBalance() - TRANSACTION_FEE);
    }

    // Public method that applies the monthly fee.
    public void applyMonthlyFee() {
        if (transactionCount > TRANSACTION_LIMIT) {
            deductTransactionFee();
        }
        transactionCount = 0;
    }

 // Public method that displays the account information.
    public void display() {
        super.display();
        System.out.println("Account Type: Checking\n");
    }
}
