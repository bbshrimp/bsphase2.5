/*
 * TEAM RED
 * -Mario Garcilazo
 * -Tyler Yocom
 * -Titus Duncan
 * -December Carroll
 *
 *  GoldAccount class is a subclass of the account class. 
 *  This represents a type of bank account. 
 * 
 */


public class GoldAccount extends Account {
	// constant for interest rate
    private final double INTEREST_RATE = 0.05;

    // constructor that initializes account number, balance, and customer
    public GoldAccount(int accountNumber, double balance, Customer customer) {
        super(accountNumber, balance, customer);
    }

    // method that applies interest of the balance
    public void applyInterest() {
        double interest = super.getBalance() * INTEREST_RATE;
        super.setBalance(super.getBalance() + interest);
    }

    // method that displays account info
    public void display() {
        super.display();
        System.out.println("Account Type: Gold\n");
    }
}