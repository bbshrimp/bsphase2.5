/*
 * TEAM RED
 * -Mario Garcilazo
 * -Tyler Yocom
 * -Titus Duncan
 * -December Carroll
 * 
 * Bank Class: represents the bank system in the java application.
 * It contains an array of accounts to keep track of all accounts in the bank.
 */

import java.util.ArrayList;
import java.util.List;

public class Bank {
	// Declare an arrayList of accounts
	private List<Account> accounts;
    
    

    public Bank() {
    	// Initialize the "accounts" ArrayList to an empty ArrayList of Account objects
        accounts = new ArrayList<>();
    }

 // Define a method to add an Account object to the "accounts" ArrayList
    public boolean addAccount(Account account) {
    	if (findAccount(account.getAccountNumber()) != null) {
            return false;
        }
        accounts.add(account);
        return true;
    }
  //Method to find an existing account stored in the array
    public Account findAccount(int accountNumber) {
   	
           for (Account account : accounts) {
               if (account.getAccountNumber() == accountNumber) {
                   return account;
               }
           }
           return null;
       }

 // Method to retrieve an Account object with a specific account number 
    public Account getAccount(int accountNumber) {
    	// Loop through each Account object in the "accounts" ArrayList
        for (Account account : accounts) {
        	// Check if the account number of the current Account object matches the specified account number
            if (account.getAccountNumber() == accountNumber) {
                return account;
            }
        }
        // If no matching account is found, return null
        return null;
    }
 // method to remove a specified Account object from the "accounts" ArrayList
    public void removeAccount(Account account) {
        accounts.remove(account);
    }


    // Method to deposit money into account
    public void deposit(Account account, double amount) {
        account.deposit(amount);
    }

    // method to withdraw money from account
    public void withdraw(Account account, double amount) {
        account.withdraw(amount);
        
    }

   public void applyInterest() {
       for (Account account : accounts) {
    	   if (account instanceof GoldAccount) {
    		   ((GoldAccount)account).applyInterest();
    	   } else 
    		   if (account instanceof RegularAccount) {
    			   ((RegularAccount)account).applyInterest();
    		   }
       }
   }
     
     

    // method to apply a monthly fee to all RegularAccount objects in the "accounts" ArrayList
    public void applyMonthlyFee() {
        for (Account account : accounts) {
            if (account instanceof RegularAccount) {
                ((RegularAccount) account).applyMonthlyFee();
            }
        }
    }

    // method to return the accounts ArrayList
    public ArrayList<Account> getAccounts() {
        return (ArrayList<Account>) accounts;
    }

    // Method to display stats about the bank object associated with account
    public void displayBankStatistics() {
        double totalSum = 0.0;
        int zeroBalanceCount = 0;
        double maxBalance = Double.MIN_VALUE;
        Account maxBalanceAccount = null;

        for (Account account : accounts) {
            double balance = account.getBalance();
            totalSum = totalSum + balance;

            if (balance == 0.0) {
                zeroBalanceCount++;
            }

            if (balance > maxBalance) {
                maxBalance = balance;
                maxBalanceAccount = account;
            }
        }

        System.out.println("Bank Statistics:");
        System.out.println("Total Sum: " + totalSum);
        System.out.println("Number of Zero-Balance Accounts: " + zeroBalanceCount);
        System.out.printf("Average Balance: %.2f\n", (totalSum / accounts.size()));
        System.out.println("Account with Largest Balance: ");
        if (maxBalanceAccount == null) {
           System.out.println("N/A");
 }
            else if (maxBalanceAccount != null) {

                 maxBalanceAccount.display();
 }
 }       
 }
